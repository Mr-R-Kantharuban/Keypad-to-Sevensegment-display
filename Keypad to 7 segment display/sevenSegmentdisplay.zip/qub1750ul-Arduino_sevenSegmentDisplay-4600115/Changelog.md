symbols caption:
> \+ added
> \- removed
> = changed/fixed
> \* coming in a future release

Changelog v1.0.0

> First release